#######
My attempt at a procedural dungeon game (with some issues that still need to be worked out)
Controls:
   	Left Control Stick: Moves the player around.
	Right Control Stick: Moves the camera around.
	Start: Closes the game.
	
	WASD/Arrow Keys: Also move the player around.
	Mouse: Also moves the camera around.

Issues:
If this doesn't run, you'll probably have to change line 488 of RenderManager.cpp to the correct plugin for your system. 
Also the MakeFile was changed to match my system setup, you'll have to change it to match yours. 
There are several issues in the dungeon spawnRooms function which I will try to work out any issues with in the next few days. 
